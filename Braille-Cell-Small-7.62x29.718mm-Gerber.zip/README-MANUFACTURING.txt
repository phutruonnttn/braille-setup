BRAILLE CELL SMALL PCB - MANUFACTURING NOTES

Board: 7.620 x 29.718 mm, 2 layers, nominal 1.6 mm FR-4.
Min track: 0.2032 mm. Min clearance: 0.1524 mm. Min via drill: 0.35 mm.

IMPORTANT:
1. Do not tent the vias. Via copper must remain exposed on TOP and BOTTOM.
2. Keep the merged mask openings at the two six-pad terminal groups.
3. Confirm the mechanical outline is 7.620 x 29.718 mm before fabrication.
4. Please run vendor DFM and send the Gerber preview for approval.

Generated from the official Braille Cell.brd EAGLE source using KiCad 10.0.6.
